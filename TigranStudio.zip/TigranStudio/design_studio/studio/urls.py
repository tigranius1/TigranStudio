from django.urls import path
from . import views

app_name = 'studio'

urlpatterns = [
    # Основные страницы
    path('', views.home, name='home'),
    path('services/', views.services, name='services'),
    path('portfolio/', views.portfolio, name='portfolio'),
    path('reviews/', views.reviews_list, name='reviews'),
    
    # Формы
    path('submit-order/', views.submit_order, name='submit_order'),
    path('submit-questionnaire/', views.submit_questionnaire, name='submit_questionnaire'),
    
    # Авторизация
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('profile/', views.profile, name='profile'),
    path('add-review/', views.add_review, name='add_review'),
]