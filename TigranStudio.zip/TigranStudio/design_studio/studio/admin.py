from django.contrib import admin
from .models import Project, Review, Order, PageContent, ProjectQuestionnaire, UserProfile

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ['title', 'created_at']
    list_filter = ['created_at']
    search_fields = ['title']

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ['author', 'rating', 'status', 'created_at']
    list_filter = ['status', 'rating']
    actions = ['approve_reviews']
    
    def approve_reviews(self, request, queryset):
        queryset.update(status='approved')
    approve_reviews.short_description = 'Одобрить отзывы'

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'budget', 'created_at', 'is_viewed']
    list_filter = ['is_viewed', 'created_at']
    readonly_fields = ['created_at']

@admin.register(PageContent)
class PageContentAdmin(admin.ModelAdmin):
    list_display = ['page', 'section']
    list_filter = ['page']

@admin.register(ProjectQuestionnaire)
class ProjectQuestionnaireAdmin(admin.ModelAdmin):
    list_display = ['name', 'project_type', 'style', 'budget', 'created_at', 'is_viewed']
    list_filter = ['project_type', 'style', 'is_viewed', 'created_at']
    search_fields = ['name', 'email']
    readonly_fields = ['created_at']

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'phone', 'created_at']
    search_fields = ['user__username', 'phone']