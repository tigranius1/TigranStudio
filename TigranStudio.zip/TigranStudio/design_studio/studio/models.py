from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

class Project(models.Model):
    title = models.CharField('Название проекта', max_length=200)
    description = models.TextField('Описание')
    image = models.ImageField('Изображение', upload_to='portfolio/')
    link = models.URLField('Ссылка на проект', blank=True)
    seo_title = models.CharField('SEO Title', max_length=200, blank=True)
    seo_description = models.TextField('SEO Description', blank=True)
    created_at = models.DateTimeField('Дата', auto_now_add=True)
    
    class Meta:
        verbose_name = 'Проект'
        verbose_name_plural = 'Портфолио'
    
    def __str__(self):
        return self.title

class Review(models.Model):
    STATUS_CHOICES = [
        ('pending', 'На модерации'),
        ('approved', 'Одобрено'),
        ('rejected', 'Отклонено'),
    ]
    
    author = models.CharField('Имя', max_length=100)
    text = models.TextField('Текст отзыва')
    rating = models.IntegerField('Оценка', choices=[(i, i) for i in range(1, 6)])
    status = models.CharField('Статус', max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField('Дата', auto_now_add=True)
    
    class Meta:
        verbose_name = 'Отзыв'
        verbose_name_plural = 'Отзывы'
    
    def __str__(self):
        return f'{self.author} - {self.rating}★'

class Order(models.Model):
    name = models.CharField('Имя', max_length=100)
    email = models.EmailField('Email')
    reference_link = models.URLField('Ссылка на референс')
    budget = models.CharField('Бюджет', max_length=100)
    comment = models.TextField('Комментарий', blank=True)
    created_at = models.DateTimeField('Дата заявки', auto_now_add=True)
    is_viewed = models.BooleanField('Просмотрено', default=False)
    
    class Meta:
        verbose_name = 'Заявка'
        verbose_name_plural = 'Заявки'
    
    def __str__(self):
        return f'{self.name} - {self.email}'

class PageContent(models.Model):
    PAGE_CHOICES = [
        ('home', 'Главная страница'),
        ('services', 'Страница услуг'),
    ]
    
    page = models.CharField('Страница', max_length=20, choices=PAGE_CHOICES)
    section = models.CharField('Секция', max_length=100)
    content = models.TextField('Текст')
    
    class Meta:
        verbose_name = 'Текст страницы'
        verbose_name_plural = 'Тексты страниц'
    
    def __str__(self):
        return f'{self.get_page_display()} - {self.section}'

# НОВАЯ МОДЕЛЬ ДЛЯ ОПРОСНИКА
class ProjectQuestionnaire(models.Model):
    PROJECT_TYPES = [
        ('website', 'Сайт-визитка'),
        ('landing', 'Лендинг'),
        ('online_store', 'Интернет-магазин'),
        ('corporate', 'Корпоративный сайт'),
        ('mobile_app', 'Мобильное приложение'),
        ('other', 'Другое'),
    ]
    
    STYLES = [
        ('minimal', 'Минимализм'),
        ('modern', 'Современный'),
        ('classic', 'Классический'),
        ('creative', 'Креативный'),
        ('tech', 'Технологичный'),
        ('nature', 'Натуральный'),
        ('other', 'Свой вариант'),
    ]
    
    COLOR_SCHEMES = [
        ('light', 'Светлая'),
        ('dark', 'Темная'),
        ('colorful', 'Яркая'),
        ('pastel', 'Пастельная'),
        ('corporate', 'Корпоративная'),
        ('other', 'Свой вариант'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name='Пользователь')
    
    project_type = models.CharField('Тип проекта', max_length=50, choices=PROJECT_TYPES)
    custom_project_type = models.CharField('Свой вариант (тип проекта)', max_length=200, blank=True)
    
    style = models.CharField('Стиль', max_length=50, choices=STYLES)
    custom_style = models.CharField('Свой вариант (стиль)', max_length=200, blank=True)
    
    color_scheme = models.CharField('Цветовая гамма', max_length=50, choices=COLOR_SCHEMES)
    custom_color = models.CharField('Свой вариант (цвета)', max_length=200, blank=True)
    
    pages_count = models.IntegerField('Количество страниц', default=1)
    deadline = models.CharField('Срок', max_length=100, blank=True)
    budget = models.CharField('Бюджет', max_length=100)
    additional_info = models.TextField('Дополнительная информация', blank=True)
    
    name = models.CharField('Имя', max_length=100)
    email = models.EmailField('Email')
    phone = models.CharField('Телефон', max_length=20, blank=True)
    
    created_at = models.DateTimeField('Дата', auto_now_add=True)
    is_viewed = models.BooleanField('Просмотрено', default=False)
    
    class Meta:
        verbose_name = 'Опросник'
        verbose_name_plural = 'Опросники'
    
    def __str__(self):
        return f'{self.name} - {self.get_project_type_display()} - {self.created_at.strftime("%d.%m.%Y")}'

# МОДЕЛЬ ПРОФИЛЯ ПОЛЬЗОВАТЕЛЯ
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name='Пользователь')
    avatar = models.ImageField('Аватар', upload_to='avatars/', blank=True, null=True)
    phone = models.CharField('Телефон', max_length=20, blank=True)
    bio = models.TextField('О себе', blank=True)
    created_at = models.DateTimeField('Дата регистрации', auto_now_add=True)
    
    class Meta:
        verbose_name = 'Профиль'
        verbose_name_plural = 'Профили'
    
    def __str__(self):
        return self.user.username

# СИГНАЛЫ ДЛЯ АВТОМАТИЧЕСКОГО СОЗДАНИЯ ПРОФИЛЯ
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.userprofile.save()