from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .models import Project, Review, Order, PageContent, ProjectQuestionnaire

def home(request):
    projects = Project.objects.all()[:6]
    reviews = Review.objects.filter(status='approved')[:3]
    return render(request, 'studio/home.html', {
        'projects': projects,
        'reviews': reviews,
    })

def services(request):
    services_list = [
        {'name': 'Веб-дизайн', 'price': 'от 50 000₽', 'desc': 'Современные сайты под ключ', 'icon': '💻'},
        {'name': 'Брендинг', 'price': 'от 30 000₽', 'desc': 'Логотипы и айдентика', 'icon': '🎨'},
        {'name': 'UI/UX Дизайн', 'price': 'от 40 000₽', 'desc': 'Интерфейсы для приложений', 'icon': '📱'},
        {'name': 'Мобильный дизайн', 'price': 'от 35 000₽', 'desc': 'Дизайн для iOS/Android', 'icon': '📲'},
    ]
    return render(request, 'studio/services.html', {'services': services_list})

def portfolio(request):
    projects = Project.objects.all()
    return render(request, 'studio/portfolio.html', {'projects': projects})

def reviews_list(request):
    all_reviews = Review.objects.filter(status='approved')
    return render(request, 'studio/reviews.html', {'reviews': all_reviews})

def submit_order(request):
    if request.method == 'POST':
        order = Order.objects.create(
            name=request.POST.get('name'),
            email=request.POST.get('email'),
            reference_link=request.POST.get('reference', ''),
            budget=request.POST.get('budget', ''),
            comment=request.POST.get('comment', '')
        )
        
        send_mail(
            f'Новая заявка от {order.name}',
            f'Email: {order.email}\nБюджет: {order.budget}\nРеференс: {order.reference_link}',
            'noreply@designstudio.com',
            ['studio@example.com'],
            fail_silently=True,
        )
        
        messages.success(request, 'Спасибо! Мы свяжемся с вами!')
        return redirect('studio:home')
    
    return redirect('studio:home')

def submit_questionnaire(request):
    if request.method == 'POST':
        questionnaire = ProjectQuestionnaire.objects.create(
            user=request.user if request.user.is_authenticated else None,
            project_type=request.POST.get('project_type'),
            custom_project_type=request.POST.get('custom_project_type', ''),
            style=request.POST.get('style'),
            custom_style=request.POST.get('custom_style', ''),
            color_scheme=request.POST.get('color_scheme'),
            custom_color=request.POST.get('custom_color', ''),
            pages_count=request.POST.get('pages_count', 1),
            deadline=request.POST.get('deadline', ''),
            budget=request.POST.get('budget'),
            additional_info=request.POST.get('additional_info', ''),
            name=request.POST.get('name'),
            email=request.POST.get('email'),
            phone=request.POST.get('phone', '')
        )
        
        send_mail(
            f'Новая заявка из опросника от {questionnaire.name}',
            f"""
Имя: {questionnaire.name}
Email: {questionnaire.email}
Телефон: {questionnaire.phone}

Тип проекта: {questionnaire.get_project_type_display()}
Стиль: {questionnaire.get_style_display()}
Цвета: {questionnaire.get_color_scheme_display()}
Страниц: {questionnaire.pages_count}
Бюджет: {questionnaire.budget}
Срок: {questionnaire.deadline}

Доп. информация: {questionnaire.additional_info}
            """,
            'noreply@designstudio.com',
            ['studio@example.com'],
            fail_silently=True,
        )
        
        messages.success(request, 'Спасибо! Мы изучим ваш запрос и свяжемся с вами!')
        return redirect('studio:services')
    
    return redirect('studio:services')

# ============ АВТОРИЗАЦИЯ ============

def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        
        if password1 != password2:
            messages.error(request, 'Пароли не совпадают!')
            return redirect('studio:register')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Пользователь с таким именем уже существует!')
            return redirect('studio:register')
        
        user = User.objects.create_user(username=username, email=email, password=password1)
        login(request, user)
        messages.success(request, f'Добро пожаловать, {username}!')
        return redirect('studio:home')
    
    return render(request, 'studio/register.html')

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            messages.success(request, f'С возвращением, {username}!')
            return redirect('studio:home')
        else:
            messages.error(request, 'Неверное имя пользователя или пароль!')
    
    return render(request, 'studio/login.html')

def user_logout(request):
    logout(request)
    messages.info(request, 'Вы вышли из аккаунта')
    return redirect('studio:home')

@login_required
def profile(request):
    user_reviews = Review.objects.filter(author=request.user.username)
    user_orders = Order.objects.filter(email=request.user.email)
    user_questionnaires = ProjectQuestionnaire.objects.filter(email=request.user.email)
    
    if request.method == 'POST':
        profile = request.user.userprofile
        profile.phone = request.POST.get('phone', '')
        profile.bio = request.POST.get('bio', '')
        profile.save()
        messages.success(request, 'Профиль обновлен!')
        return redirect('studio:profile')
    
    return render(request, 'studio/profile.html', {
        'user_reviews': user_reviews,
        'user_orders': user_orders,
        'user_questionnaires': user_questionnaires,
    })

@login_required
def add_review(request):
    if request.method == 'POST':
        text = request.POST.get('text')
        rating = request.POST.get('rating')
        
        Review.objects.create(
            author=request.user.username,
            text=text,
            rating=rating,
            status='pending'
        )
        messages.success(request, 'Спасибо за отзыв! Он будет опубликован после модерации.')
        return redirect('studio:reviews')
    
    return redirect('studio:reviews')